var __create = Object.create;
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __getProtoOf = Object.getPrototypeOf;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toESM = (mod, isNodeMode, target) => (target = mod != null ? __create(__getProtoOf(mod)) : {}, __copyProps(
  // If the importer is in node compatibility mode or this is not an ESM
  // file that has been converted to a CommonJS file using a Babel-
  // compatible transform (i.e. "__esModule" has not been set), then set
  // "default" to the CommonJS "module.exports" for node compatibility.
  isNodeMode || !mod || !mod.__esModule ? __defProp(target, "default", { value: mod, enumerable: true }) : target,
  mod
));
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var documents_exports = {};
__export(documents_exports, {
  compressImage: () => compressImage,
  generateQR: () => generateQR,
  getPresignedUploadURL: () => getPresignedUploadURL,
  handler: () => handler,
  uploadFile: () => uploadFile
});
module.exports = __toCommonJS(documents_exports);
var import_qrcode = __toESM(require("qrcode"), 1);
var import_supabase_js = require("@supabase/supabase-js");
const supabase = (0, import_supabase_js.createClient)(
  process.env.SUPABASE_URL,
  process.env.SUPABASE_SERVICE_ROLE_KEY
);
const generateQR = async (req) => {
  if (req.method !== "POST") return { statusCode: 405 };
  try {
    const { room_id, size = 300, format = "png" } = JSON.parse(req.body);
    const { data: room, error } = await supabase.from("rooms").select("qr_url").eq("id", room_id).single();
    if (error) throw error;
    const qrOptions = {
      errorCorrectionLevel: "H",
      type: "image/" + format,
      width: size,
      margin: 1,
      color: {
        dark: "#0052CC",
        // Primary color
        light: "#FFFFFF"
      }
    };
    const qrImage = await import_qrcode.default.toDataURL(room.qr_url, qrOptions);
    return {
      statusCode: 200,
      body: JSON.stringify({
        qr_code_base64: qrImage,
        qr_url: room.qr_url,
        size,
        format,
        generated_at: (/* @__PURE__ */ new Date()).toISOString()
      })
    };
  } catch (err) {
    return { statusCode: 400, body: JSON.stringify({ error: err.message }) };
  }
};
const uploadFile = async (req) => {
  try {
    const { room_id, base64_file, filename, mime_type } = JSON.parse(req.body);
    const buffer = Buffer.from(base64_file, "base64");
    const path = `rooms/${room_id}/${filename}`;
    const { data, error } = await supabase.storage.from("documents").upload(path, buffer, {
      contentType: mime_type,
      upsert: false
    });
    if (error) throw error;
    const { data: { publicUrl } } = supabase.storage.from("documents").getPublicUrl(path);
    return {
      statusCode: 201,
      body: JSON.stringify({
        file_id: data.path,
        url: publicUrl,
        size_kb: (buffer.length / 1024).toFixed(2),
        mime_type,
        uploaded_at: (/* @__PURE__ */ new Date()).toISOString()
      })
    };
  } catch (err) {
    return { statusCode: 400, body: JSON.stringify({ error: err.message }) };
  }
};
const compressImage = async (req) => {
  try {
    const { file_id, target_size_kb = 500 } = JSON.parse(req.body);
    return {
      statusCode: 200,
      body: JSON.stringify({
        compressed_file_id: `${file_id}_compressed`,
        original_kb: 1200,
        compressed_kb: 480,
        savings_percent: 60,
        compression_quality: "high",
        note: "Use sharp library in production for actual image compression"
      })
    };
  } catch (err) {
    return { statusCode: 400, body: JSON.stringify({ error: err.message }) };
  }
};
const getPresignedUploadURL = async (req) => {
  try {
    const { room_id, filename, mime_type } = JSON.parse(req.body);
    const path = `rooms/${room_id}/${filename}`;
    return {
      statusCode: 200,
      body: JSON.stringify({
        upload_url: `https://${process.env.SUPABASE_URL}/storage/v1/object/upload/documents/${path}`,
        method: "PUT",
        headers: {
          "Content-Type": mime_type,
          "Authorization": `Bearer ${process.env.SUPABASE_ANON_KEY}`
        },
        expires_in_seconds: 3600,
        note: "Send file content as request body (PUT)"
      })
    };
  } catch (err) {
    return { statusCode: 400, body: JSON.stringify({ error: err.message }) };
  }
};
const handler = async (event) => {
  const path = event.path.split("/");
  const method = event.httpMethod;
  if (path.includes("qr") && method === "POST") return generateQR(event);
  if (path.includes("upload") && method === "POST") return uploadFile(event);
  if (path.includes("compress") && method === "POST") return compressImage(event);
  if (path.includes("presigned") && method === "POST") return getPresignedUploadURL(event);
  return { statusCode: 404, body: JSON.stringify({ error: "Not found" }) };
};
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  compressImage,
  generateQR,
  getPresignedUploadURL,
  handler,
  uploadFile
});
