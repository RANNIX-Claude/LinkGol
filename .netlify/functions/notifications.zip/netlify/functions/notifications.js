var __create = Object.create;
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __getProtoOf = Object.getPrototypeOf;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toESM = (mod, isNodeMode, target) => (target = mod != null ? __create(__getProtoOf(mod)) : {}, __copyProps(
  // If the importer is in node compatibility mode or this is not an ESM
  // file that has been converted to a CommonJS file using a Babel-
  // compatible transform (i.e. "__esModule" has not been set), then set
  // "default" to the CommonJS "module.exports" for node compatibility.
  isNodeMode || !mod || !mod.__esModule ? __defProp(target, "default", { value: mod, enumerable: true }) : target,
  mod
));
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var notifications_exports = {};
__export(notifications_exports, {
  handleResendWebhook: () => handleResendWebhook,
  handler: () => handler,
  sendEmail: () => sendEmail,
  sendPushNotification: () => sendPushNotification,
  sendSMS: () => sendSMS,
  sendTestNotification: () => sendTestNotification
});
module.exports = __toCommonJS(notifications_exports);
var import_resend = require("resend");
var import_twilio = __toESM(require("twilio"), 1);
const resend = new import_resend.Resend(process.env.RESEND_API_KEY);
const twilioClient = (0, import_twilio.default)(process.env.TWILIO_ACCOUNT_SID, process.env.TWILIO_AUTH_TOKEN);
const EMAIL_TEMPLATES = {
  room_invitation: (data) => ({
    subject: `\xA1Tu sala ${data.room_name} est\xE1 lista! \u{1F389}`,
    html: `
      <h1>Sala creada exitosamente</h1>
      <p>Hola ${data.host_name},</p>
      <p>Tu sala "${data.room_name}" est\xE1 lista para recibir invitados.</p>
      <p><strong>URL:</strong> ${data.room_url}</p>
      <p>
        <a href="${data.room_url}" style="background: #0052CC; color: white; padding: 10px 20px; border-radius: 5px; text-decoration: none;">
          Abrir Sala
        </a>
      </p>
      <p><small>Este enlace expira en 30 d\xEDas.</small></p>
    `
  }),
  user_joined: (data) => ({
    subject: `\u2728 ${data.guest_name} se ha unido a tu sala`,
    html: `
      <h1>Nuevo invitado</h1>
      <p>Hola ${data.host_name},</p>
      <p><strong>${data.guest_name}</strong> acaba de unirse a tu sala "${data.room_name}".</p>
      <p>Idioma: <strong>${data.guest_language}</strong></p>
      <p><a href="${data.room_url}">Ver sala</a></p>
    `
  }),
  translation_ready: (data) => ({
    subject: `Traducci\xF3n lista: "${data.room_name}"`,
    html: `
      <h1>Nuevos mensajes traducidos</h1>
      <p>Hola ${data.recipient_name},</p>
      <p>Tienes <strong>${data.message_count}</strong> nuevos mensaje(s) en "${data.room_name}".</p>
      <p><a href="${data.room_url}">Ver mensajes</a></p>
    `
  }),
  room_summary: (data) => ({
    subject: `Resumen de sala: ${data.room_name}`,
    html: `
      <h1>Resumen de conversaci\xF3n</h1>
      <p>Hola ${data.host_name},</p>
      <p><strong>Sala:</strong> ${data.room_name}</p>
      <p><strong>Duraci\xF3n:</strong> ${data.duration_minutes} minutos</p>
      <p><strong>Participantes:</strong> ${data.participants_count}</p>
      <p><strong>Mensajes:</strong> ${data.message_count}</p>
      <h2>Resumen:</h2>
      <p>${data.summary}</p>
      <p><strong>Temas clave:</strong> ${data.key_topics?.join(", ")}</p>
      <p><strong>Sentimiento general:</strong> ${data.sentiment}</p>
    `
  })
};
const sendEmail = async (req) => {
  if (req.method !== "POST") return { statusCode: 405 };
  try {
    const { to, template, variables } = JSON.parse(req.body);
    if (!EMAIL_TEMPLATES[template]) {
      throw new Error(`Unknown template: ${template}`);
    }
    const emailContent = EMAIL_TEMPLATES[template](variables);
    const result = await resend.emails.send({
      from: "noreply@linkgol.app",
      to,
      subject: emailContent.subject,
      html: emailContent.html
    });
    if (result.error) throw result.error;
    return {
      statusCode: 200,
      body: JSON.stringify({
        email_id: result.data?.id,
        status: "sent",
        sent_at: (/* @__PURE__ */ new Date()).toISOString(),
        to
      })
    };
  } catch (err) {
    console.error("Email error:", err);
    return { statusCode: 400, body: JSON.stringify({ error: err.message }) };
  }
};
const sendSMS = async (req) => {
  if (req.method !== "POST") return { statusCode: 405 };
  try {
    const { phone, message, country_code = "es" } = JSON.parse(req.body);
    if (!phone.startsWith("+")) {
      throw new Error("Phone must start with + and country code");
    }
    const sms = await twilioClient.messages.create({
      body: message,
      from: process.env.TWILIO_PHONE_NUMBER,
      to: phone
    });
    return {
      statusCode: 200,
      body: JSON.stringify({
        sms_id: sms.sid,
        status: sms.status,
        sent_at: (/* @__PURE__ */ new Date()).toISOString(),
        to: phone,
        message_length: message.length
      })
    };
  } catch (err) {
    console.error("SMS error:", err);
    return { statusCode: 400, body: JSON.stringify({ error: err.message }) };
  }
};
const sendPushNotification = async (req) => {
  if (req.method !== "POST") return { statusCode: 405 };
  try {
    const { user_id, title, body, action_url } = JSON.parse(req.body);
    return {
      statusCode: 200,
      body: JSON.stringify({
        push_id: `push_${Date.now()}`,
        sent: 1,
        failed: 0,
        title,
        body,
        user_id
      })
    };
  } catch (err) {
    console.error("Push notification error:", err);
    return { statusCode: 400, body: JSON.stringify({ error: err.message }) };
  }
};
const sendTestNotification = async (req) => {
  if (req.method !== "POST") return { statusCode: 405 };
  try {
    const { type = "email", to, phone } = JSON.parse(req.body);
    if (type === "email") {
      return sendEmail({
        method: "POST",
        body: JSON.stringify({
          to,
          template: "room_invitation",
          variables: {
            host_name: "Test User",
            room_name: "Test Room",
            room_url: "https://linkgol.app/room/test-123"
          }
        })
      });
    } else if (type === "sms") {
      return sendSMS({
        method: "POST",
        body: JSON.stringify({
          phone,
          message: "\xA1LinkGol aqu\xED! Tu sala est\xE1 lista. linkgol.app"
        })
      });
    }
    throw new Error("Unknown notification type");
  } catch (err) {
    return { statusCode: 400, body: JSON.stringify({ error: err.message }) };
  }
};
const handleResendWebhook = async (req) => {
  if (req.method !== "POST") return { statusCode: 405 };
  try {
    const event = JSON.parse(req.body);
    console.log("Resend webhook:", event.type, event.data?.email_id);
    return { statusCode: 200, body: JSON.stringify({ received: true }) };
  } catch (err) {
    console.error("Webhook error:", err);
    return { statusCode: 400, body: JSON.stringify({ error: err.message }) };
  }
};
const handler = async (event) => {
  const path = event.path.split("/");
  const method = event.httpMethod;
  if (path.includes("email") && method === "POST") return sendEmail(event);
  if (path.includes("sms") && method === "POST") return sendSMS(event);
  if (path.includes("push") && method === "POST") return sendPushNotification(event);
  if (path.includes("test") && method === "POST") return sendTestNotification(event);
  if (path.includes("webhook") && path.includes("resend")) return handleResendWebhook(event);
  return { statusCode: 404, body: JSON.stringify({ error: "Not found" }) };
};
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  handleResendWebhook,
  handler,
  sendEmail,
  sendPushNotification,
  sendSMS,
  sendTestNotification
});
